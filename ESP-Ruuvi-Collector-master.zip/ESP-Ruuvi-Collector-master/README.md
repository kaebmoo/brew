# ESP-Ruuvi-Collector
ESP32 firmware serving as a bridge between Ruuvi Tag with Ruuvi firmware and InfluxDB written in Arduino IDE

You will have to change the partition to get the required flash space (quite easy, just look into the board configuration drop down in the IDE).
